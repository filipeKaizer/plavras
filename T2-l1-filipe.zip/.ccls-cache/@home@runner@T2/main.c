// l123b - t2 (acerte a letra)
// programa para digitar letras dentro do limite de tempo
// Filipe Sacchet Kaizer
// 2023-10-17

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include "tecla.h"
#include "tela.h"

// quantas palavras a gerar
#define N_PAL 10
// quantos segundos para digitar
#define TEMPO 20
// Quantas palavras tem no arquivo
#define MAX_PAL 920

// Verifica se a letra c informada é a primeira do vetor. Se for, remove.
int remove_letra(char v[16], char p);
// Remove uma palavra do vetor
void remove_palavra(char palavras[][16], int index);
// Seleciona a palavra que será removida, se for a primeira letra
int seleciona_palavra(char v[][16], char letra);
// Testa a palavra
bool testa_palavra(char v[]);
// apresenta o programa
void apresentacao();
// encerra o programa
void encerramento();
// apresenta os parabens e será usado no futuro para salvar o score
void ganhou();
// apresenta a situação corrente do jogo e verifica se e para parar.
bool terminou(double timeIni, int n_palavras);
// executa uma partida
void jogo();
// verifica a vontade do jogador
bool quer_jogar_de_novo();
// limpa a linha de entrada
void espera_enter();
// abre arquivo e sorteia palavras
bool sorteia_palavras(char palavras[N_PAL][16], int tam);
// atualiza a tela do jogo com as palavras e o tempo
void desenha_tela(char palavras[][16], int palavraSelecionada, double tempoRestante);

struct palavras {
char palavra[16];
double tempo;
int tempoAtivacao;
};


int main()
{
  // inicializa o gerador de números aleatórios
  srand(time(0));

  apresentacao();

  do {    
    tela_ini();
    tecla_ini();

    jogo();
    
    tecla_fim();
    tela_fim();
  } while(quer_jogar_de_novo());

  encerramento();
}

void jogo()
{
  // inicializa o vetor de números a digitar
  int n_palavras = N_PAL;
  // inicializa tempo
  double tempo_inicial = tela_relogio();
  // Indice para determinar a palavra a ser digitada
  int palavraSelecionada = -1;
  // Matriz de palavras
  char palavras[N_PAL][16];
  // Vetor de struct palavras
  

  if (!sorteia_palavras(palavras, N_PAL)) {
    return;
  }
  
  while (true) {
    if (terminou(tempo_inicial, n_palavras)) {
      break;
    }
      
    desenha_tela(palavras, palavraSelecionada, tempo_inicial);
    
    char letra='\0';
    letra = tecla_le_char();
        
    if (palavraSelecionada == -1 && letra != '\0') {
      palavraSelecionada = seleciona_palavra(palavras, letra);
    }
    if (palavraSelecionada != -1 && remove_letra(palavras[palavraSelecionada], letra) == 1) {         
      remove_palavra(palavras, palavraSelecionada);
      palavraSelecionada = -1;      
      n_palavras--; 
    }
  }
}

void desenha_tela(char palavras[][16], int palavraSelecionada, double tempoInicial)
{
  
  tela_limpa();
  int linhas = tela_nlin();
  int colunas = tela_ncol();

  // DESENHA AS PALAVRAS NÃO SELECIONADAS
  tela_lincol(0, 0);
  
  for (int i = 0; palavras[i][0] != '\0' && i < 10; i++) {
    if (i != palavraSelecionada) {
      tela_cor_letra(20, 200, 90); 
      printf("%s", palavras[i]);
      tela_cor_normal();
      printf(" ");
    }
  }
  
  // DESENHA PALAVRA SELECIONADA 
  linhas = linhas / 2 - 1;
  if (palavraSelecionada == -1) {
    colunas = colunas / 2 - 17 / 2;
    
    tela_cor_letra(121, 123, 0);
    tela_lincol(linhas, colunas);
    printf("INFORME UMA LETRA");
  } else {
    colunas = colunas / 2 - (strlen(palavras[palavraSelecionada]) + 4) / 2;

    tela_cor_letra(204, 37, 0);
    tela_lincol(linhas, colunas);
    printf("< %s >", palavras[palavraSelecionada]);
  }

  // DESENHA O TEMPO RESTANTE
  double tempoRestante =  TEMPO - (tela_relogio() - tempoInicial);
  if (tempoRestante < 5) {
    tela_cor_letra(205, 10, 0);
  } else {
    tela_cor_letra(0, 205, 70);
  }

  tela_lincol(tela_nlin(), tela_ncol() / 2 - 18 / 2);
  printf("Tempo: %.1f segundos", tempoRestante);
  
  // APLICA AS CONFIGURAÇÕES 
  tela_atualiza();
}

void apresentacao()
{
  printf("Você deve digitar os números que aparecerão na tela.\n");
  printf("A ordem não é importante.\n");
  printf("Tecle <enter> para iniciar. ");
  espera_enter();
}

void encerramento()
{
  printf("Até a próxima.\n");
}

bool terminou(double timeIni, int n_palavras) 
{
  double restante = TEMPO - (tela_relogio() - timeIni);
  
  if (restante <= 0) {
    // Game over pelo tempo
    tela_limpa();
    
    int linha = tela_nlin() / 2;
    int coluna = tela_ncol() / 2 - 18 / 2;

    tela_cor_letra(205, 10, 0);
    tela_lincol(linha, coluna);
    printf("Tempo esgotado! :(");

    tela_atualiza();
    return true;
    
  } else if (n_palavras == 0) {
    tela_limpa();
    
    int linha = tela_nlin() / 2;
    int coluna = tela_ncol() / 2 - 11 / 2;

    tela_cor_letra(10, 205, 0);
    tela_lincol(linha, coluna);
    printf("PARABENS!!!");

    tela_atualiza();
    return true;
  } else {
    return false;
  }
}

void mostra_tempo(long timeIni)
{
  int resta = TEMPO - (time(0) - timeIni);
  
  printf("você tem %d segundos\n", resta);
  printf("digite uma das palavras: ");
}

bool quer_jogar_de_novo()
{
  // limpa a entrada
  espera_enter();

  printf("Digite 's' para jogar de novo ");
  while (true) {
    char c = getchar();
    if (c == '\n') {
      return false;
    } else if (c == 's' || c == 'S') {
      espera_enter();
      return true;
    }
  }
}

void espera_enter()
{
  while (getchar() != '\n') {
    ; /* não faz nada */
  }
}

int remove_letra(char v[16], char p)
{
  if (v[0] == p){
    char letraRemovida = p;
    int i = 0;
    if (v[1] == '\0') {
      v[0] = '\0';
      return 1;
    }
    for (/*Nada*/; v[i+1] != '\0'; i++){
      v[i] = v[i+1]; 
    }
    v[i] = '\0';
  }
  return 0;
}

void remove_palavra(char palavras[][16], int palavraIndex)
{
  int i;
  for (i = palavraIndex; palavras[i+1][0] != '\0' && i < MAX_PAL; i++) {
    strcpy(palavras[i], palavras[i+1]);
  }
  palavras[i][0] = '\0';
}

bool sorteia_palavras(char palavras[][16], int tam)
{
  FILE *arquivo;
  char palavraLida[16];
  char palavrasArquivo[920][16];

  arquivo = fopen("palavras", "r");

  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo.\n");
    return false;
  } else {
    //Lê todas as palavras do arquivo
    for (int i = 0; i< MAX_PAL; i++){
      fscanf(arquivo, "%s", &palavraLida);
      strcpy(palavrasArquivo[i], palavraLida);
    }
    int i=0; 
    while (i < tam) {
      int n = rand() % MAX_PAL;
      if (testa_palavra(palavrasArquivo[n])) { 
        strcpy(palavras[i], palavrasArquivo[n]);
        i++;
      } 
    }
    fclose(arquivo);
    return true;
  }
}

bool testa_palavra(char palavra[])
{
  for (int i = 0; palavra[i] != '\0'; i++) {
    // Se houver maiuscula, troca para minuscula.
    if (palavra[i] >= 'A' && palavra[i] <= 'Z') {
      palavra[i] += 32; // As maiuscula - minusculas da tabela Ascii
    }
    
    if (!(palavra[i] >= 'a' && palavra[i] <= 'z')) {
      return false;
      break;
    }
  }
  return true;
}

int seleciona_palavra(char v[][16], char letra) 
{
  for (int i = 0; i < N_PAL; i++){
    if (v[i][0] == letra) {
      return i; // Achou uma, retorna seu indice
    }
  } 
  return -1; // Achou nenhuma, retorna -1
}